/*
 * Virtio ring manipulation routines
 *
 * Copyright 2017 Red Hat, Inc.
 *
 * Authors:
 *  Ladi Prosek <lprosek@redhat.com>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met :
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and / or other materials provided with the distribution.
 * 3. Neither the names of the copyright holders nor the names of their contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
#include "osdep.h"
#include "virtio_pci.h"
#include "virtio.h"
#include "kdebugprint.h"
#include "virtio_ring.h"

#define DESC_INDEX(num, i) ((i) & ((num) - 1))

//Arley@20180416, IPERF3: VBOX kernel needs fixed buffer maps(idx, addr)!
#define VBOX_SUPPORT_NEWDRV 1
#if defined(VBOX_FixedBufferMaps_NoUseIndirect)

//Arley@20180416, IPERF3: if always print, go dying!
#define VBOX_FixedBufferMaps_DBGLOG

//Same with the vbox side, for rxbuf.
//see VirtualBox-5.1.30\src\VBox\Devices\Network\DevVirtioNet.cpp: vnetConstruct. --
#define VBOXQUEUE_RXSLOT  0
#define VBOXQUEUE_TXSLOT  1
#define VBOXQUEUE_CXSLOT  2

//See "../NetKVM/Common/ndis56common.h"    for struct 'RxNetDescriptor' --
extern unsigned int RxNetDescriptor_IDXOFFSET;
#define pRxNetDescriptor_idx(p)  *(u16*)((char*)(p) + RxNetDescriptor_IDXOFFSET)
#endif

/* Returns the index of the first unused descriptor */
static inline u16 get_unused_desc(struct virtqueue *vq)
{
    u16 idx = vq->first_unused;
    ASSERT(vq->num_unused > 0);

    vq->first_unused = vq->vring.desc[idx].next;
    vq->num_unused--;
    return idx;
}

/* Marks the descriptor chain starting at index idx as unused */
static inline void put_unused_desc_chain(struct virtqueue *vq, u16 idx)
{
    u16 start = idx;

    vq->opaque[idx] = NULL;
    while (vq->vring.desc[idx].flags & VIRTQ_DESC_F_NEXT) {
        idx = vq->vring.desc[idx].next;
        vq->num_unused++;
    }

    vq->vring.desc[idx].flags = VIRTQ_DESC_F_NEXT;
    vq->vring.desc[idx].next = vq->first_unused;
    vq->num_unused++;

    vq->first_unused = start;
}

//Arley@20180809, VRINGDBG: some debug fields --
#if defined(VBOX_VRingDbgField)
static FORCEINLINE void FirstUpdateVringAvailIdxShadow(struct virtqueue *vq)
{
	struct vring *vring = &vq->vring;
	u16 vring_avail_idx16 = vq->master_vring_avail.idx +1;
	u32 vring_avail_idx_shadow32 = vring_idx_shadow_MakeValue32( vring_avail_idx16);
	vring_avail_idx_shadow(vring) = vring_avail_idx_shadow32;
}
#endif

/* Adds a buffer to a virtqueue, returns 0 on success, negative number on error */
int virtqueue_add_buf(
    struct virtqueue *vq,    /* the queue */
    struct scatterlist sg[], /* sg array of length out + in */
    unsigned int out,        /* number of driver->device buffer descriptors in sg */
    unsigned int in,         /* number of device->driver buffer descriptors in sg */
    void *opaque,            /* later returned from virtqueue_get_buf */
    void *va_indirect,       /* VA of the indirect page or NULL */
    ULONGLONG phys_indirect) /* PA of the indirect page or 0 */
{
    struct vring *vring = &vq->vring;
    unsigned int i;
    u16 idx;

//Arley@20180416, IPERF3: VBOX kernel needs fixed buffer maps(idx, addr)!
#if defined(VBOX_FixedBufferMaps_NoUseIndirect)
	//If add when reusing , then crash.
	if(vq->fBufferReusing != 0){
		DPrintf(0, "[%s]vqueue(%d/%p), why new buffer when reusing(opaque:%p)?\n", __FUNCTION__,
			vq->index,vq, opaque);

		//TODO: how to add the new buffer with the correct position?
		return -ENOSPC;
	}
#endif

    if (va_indirect && (out + in) > 1 && vq->num_unused > 0) {
        /* Use one indirect descriptor */
        struct vring_desc *desc = (struct vring_desc *)va_indirect;

        for (i = 0; i < out + in; i++) {
            desc[i].flags = (i < out ? 0 : VIRTQ_DESC_F_WRITE);
            desc[i].flags |= VIRTQ_DESC_F_NEXT;
            desc[i].addr = sg[i].physAddr.QuadPart;
            desc[i].len = sg[i].length;
            desc[i].next = (u16)i + 1;
        }
        desc[i - 1].flags &= ~VIRTQ_DESC_F_NEXT;

        idx = get_unused_desc(vq);
        vq->vring.desc[idx].flags = VIRTQ_DESC_F_INDIRECT;
        vq->vring.desc[idx].addr = phys_indirect;
        vq->vring.desc[idx].len = i * sizeof(struct vring_desc);

        vq->opaque[idx] = opaque;
    } else {
        u16 last_idx;

        /* Use out + in regular descriptors */
        if (out + in > vq->num_unused) {
#if defined(VBOX_FixedBufferMaps_NoUseIndirect)
			DPrintf(1, "[%s]vqueue(%d/%p), descriptors in the vring.avail used out[avail_idx(%d)/last_used(%d)].\n",
				__FUNCTION__,
				vq->index,vq,
				vq->master_vring_avail.idx,
				vq->last_used);
			
			//Arley@20180606, TXFLOWCTRL: [TX] Why so less idle items, data pending? kick it!
			/*//Arley@20190107, Unstable TXK debugging --
			if( vq->index == VBOXQUEUE_TXSLOT)
				virtqueue_kick_always( vq); //maybe slower?
			//*/
#endif
            return -ENOSPC;
        }

        /* First descriptor */
        idx = last_idx = get_unused_desc(vq);
        vq->opaque[idx] = opaque;

        vring->desc[idx].addr = sg[0].physAddr.QuadPart;
        vring->desc[idx].len = sg[0].length;
        vring->desc[idx].flags = VIRTQ_DESC_F_NEXT;
        if (out == 0) {
            vring->desc[idx].flags |= VIRTQ_DESC_F_WRITE;
        }
        vring->desc[idx].next = vq->first_unused;
		
#if defined(VBOX_FixedBufferMaps_DBGLOG)
		DPrintf(5, "[%s]vqueue(%d/%p),vring[idx:%d, addr:0X%016I64X, opaque:%p].\n", __FUNCTION__,
			vq->index,vq, idx, vring->desc[idx].addr, opaque);
#endif

        /* The rest of descriptors */
        for (i = 1; i < out + in; i++) {
            last_idx = get_unused_desc(vq);

            vring->desc[last_idx].addr = sg[i].physAddr.QuadPart;
            vring->desc[last_idx].len = sg[i].length;
            vring->desc[last_idx].flags = VIRTQ_DESC_F_NEXT;
            if (i >= out) {
                vring->desc[last_idx].flags |= VIRTQ_DESC_F_WRITE;
            }
            vring->desc[last_idx].next = vq->first_unused;

#if defined(VBOX_FixedBufferMaps_DBGLOG)
			DPrintf(5, "[%s]vqueue(%d/%p),vring[idx:%d, addr:0X%016I64X, opaque:%p].\n", __FUNCTION__,
				vq->index,vq, last_idx, vring->desc[last_idx].addr, opaque);
#endif
        }
        vring->desc[last_idx].flags &= ~VIRTQ_DESC_F_NEXT;

//Arley@20180416, IPERF3: VBOX kernel needs a fixed RX buffer maps(idx, addr)!
#if defined(VBOX_FixedBufferMaps_NoUseIndirect)
		if(vq->index == VBOXQUEUE_RXSLOT){
			if(NULL != opaque){
				pRxNetDescriptor_idx(opaque) = idx;
			}
#if defined(VBOX_FixedBufferMaps_DBGLOG_XPNEED)
			if((out + in) !=  2){ //SHOULD BE SAME WITH the first adding!
				DPrintf(0, "[%s] NOTE: RX vqueue(%d/%p),vring added item(%d)[descriptor idx:%d, addr:0X%016I64X(length:%d,in:%d,out:%d), opaque:%p] is strange(!=2).\n",
					__FUNCTION__,
					vq->index, vq, vq->master_vring_avail.idx,
					idx, vq->vring.desc[idx].addr, vq->vring.desc[idx].len, in, out,
					opaque);
			}
#endif
		}
#endif
#if defined(VBOX_FixedBufferMaps_DBGLOG)
		DPrintf(5, "[%s]vqueue(%d/%p),vring avail(%d)[idx:%d, addr:0X%016I64X(len:%d,in:%d,out:%d), opaque:%p].\n",
			__FUNCTION__,
			vq->index, vq, vq->master_vring_avail.idx,
			idx, vq->vring.desc[idx].addr, vq->vring.desc[idx].len, in, out,
			opaque);
#endif
    }

    /* Write the first descriptor into the available ring */
    vring->avail->ring[DESC_INDEX(vring->num, vq->master_vring_avail.idx)] = idx;
    KeMemoryBarrier();

//Arley@20180809, VRINGDBG: some debug fields --
#if defined(VBOX_VRingDbgField)
	FirstUpdateVringAvailIdxShadow(vq);
#endif	
    vring->avail->idx = ++vq->master_vring_avail.idx;
    vq->num_added_since_kick++;

//Arley@20180809, VRINGDBG: some debug fields --
#if defined(VBOX_VRingDbgField)
	if(vq->master_vring_avail.idx == 0){
		vring_avail_wrap_rounds(vring)++;
		DPrintf(0, "[%s]vqueue(%d/%p), vring.avai next[%X^%04X/%08X]/processing[%X^%04X],vring.used next[%X^%04X/%08X]/processing[%X^%04X].\n",
			__FUNCTION__,
			vq->index, vq,
			vring_avail_wrap_rounds( vring),vq->vring.avail->idx,vring_avail_idx_shadow(vring), 
			vring_processed_avail_rounds( vring),vring_processing_avail_idx( vring),
			vring_used_wrap_rounds( vring),vq->vring.used->idx, vring_used_idx_shadow( vring),
			vring_processed_used_rounds( vring),vring_processing_used_idx( vring));
	}
#endif

    return 0;
}

//Arley@20180416, IPERF3: VBOX kernel needs fixed buffer maps(idx, addr)!!!
#if defined(VBOX_FixedBufferMaps_NoUseIndirect)
//SLOW VERSION---
static inline u16 _get_reused_desc_SLOWADDR(struct virtqueue *vq, const __virtio64 addr)
{
	register unsigned int n = vq->vring.num-1;
	register unsigned int i;

	//SEARCH THE REUSED LINK NODE ---
	for(i=0; i<n; i++){
		if(addr == vq->vring.desc[ i].addr) break;
	}

//Arley@20180416, IPERF3: if print, go dying!
#if defined(VBOX_FixedBufferMaps_DBGLOG)
	DPrintf(5, "[%s]vqueue(%d/%p), addr:0X%016I64X, returned:%d.\n", __FUNCTION__,
		vq->index, vq, addr, (u16)i);
#endif

	//SHOULD BE NO NEW BUFFERS HERE, BUT WHY???
	ASSERT(i < n);
	if(i == n) return (u16)-1;
	return (u16)i;
}

//FAST VERSION ---
static inline u16 _get_reused_desc_FASTIDX(struct virtqueue *vq, void* opaque)
{
//Arley@20180416, IPERF3: if print, go dying!
#if defined(VBOX_FixedBufferMaps_DBGLOG)
	DPrintf(5, "[%s]vqueue(%d/%p), opaque:%p, RxNetDescriptor_IDXOFFSET:%d, returned:%d.\n", __FUNCTION__,
		vq->index, vq, opaque, RxNetDescriptor_IDXOFFSET, pRxNetDescriptor_idx( opaque));
#endif

	return pRxNetDescriptor_idx( opaque);
}
#endif

int virtqueue_reuse_rxbuf(
    struct virtqueue *vq,    /* the queue */
    struct scatterlist sg[], /* sg array of length out + in */
    unsigned int out,        /* number of driver->device buffer descriptors in sg */
    unsigned int in,         /* number of device->driver buffer descriptors in sg */
    void *opaque,            /* later returned from virtqueue_get_buf */
    void *va_indirect,       /* VA of the indirect page or NULL */
    ULONGLONG phys_indirect) /* PA of the indirect page or 0 */
{
    struct vring *vring = &vq->vring;
    u16 idx, last_idx, pre_idx;
	register unsigned int i,n;

	//Arley@20180401, NOTE: VBOX5.1.30, actually no feature: VIRTIO_RING_F_INDIRECT_DESC!!!
	ASSERT( NULL ==va_indirect);
	ASSERT( NULL ==phys_indirect);

//Arley@20180416, IPERF3: VBOX kernel needs fixed buffer maps(idx, addr)!!!
#if defined(VBOX_FixedBufferMaps_NoUseIndirect)
	//A SLOW VERSION !!!
	//idx = last_idx= pre_idx= _get_reused_desc_SLOWADDR(vq, (__virtio64)sg[0].physAddr.QuadPart);
	//
	//WHY: a new buffer with no opaque?
	if(NULL == opaque) return -EINVALIDRES;
    idx = last_idx= pre_idx= _get_reused_desc_FASTIDX(vq, opaque);
	if(((u16)-1) == idx){
		DPrintf(0, "[%s]ERROR: RX vqueue(%d/%p), why new buffer(args: sg[0].physAddr.QuadPart/0X%016I64X, len/%d, in/%d,out/%d)?\n", __FUNCTION__,
			vq->index,vq,
			sg[0].physAddr.QuadPart, sg[0].length,
			in, out);

		//TODO: how to add the new buffer with the correct position?
		return -ENOSPC;
	}
	if(idx >= vring->num){
		DPrintf(0, "[%s]ERROR: RX vqueue(%d/%p), got wrong descriptior index(%d) from opaque(%p).\n", __FUNCTION__,
			vq->index,vq, idx, opaque);
		return -EINVALIDRES;
	}
	
	//If add when reusing , then crash.
	InterlockedExchange(&(vq->fBufferReusing), 1);
#else
	//JUST FOR COMPILING IF NO FEATURE.
	return virtqueue_add_buf(vq, sg, out, in, opaque, va_indirect, phys_indirect);
#endif

  	{//Each buffer link keeps unchanged!!!
  		// 1. Process the entry descriptor
#if defined(VBOX_FixedBufferMaps_DBGLOG)
		if(vring->desc[idx].addr != sg[0].physAddr.QuadPart){
			DPrintf(0, "[%s]ERROR: RX vqueue(%d/%p) vring item[idx:%d, current PA:0X%016I64X] is changing[new PA:0X%016I64X].\n", __FUNCTION__,
				vq->index,vq, idx, vring->desc[idx].addr, sg[0].physAddr.QuadPart);
		}
		if(vring->desc[idx].len != sg[0].length){
			DPrintf(0, "[%s]ERROR: RX vqueue(%d/%p) vring item[idx:%d, current length:%u] is changing[new length:%lu].\n", __FUNCTION__,
				vq->index,vq, idx, vring->desc[idx].len, sg[0].length);
		}
#endif
        vq->opaque[idx] = opaque;
        vring->desc[idx].addr = sg[0].physAddr.QuadPart;
        vring->desc[idx].len = sg[0].length;
        vring->desc[idx].flags =  (VIRTQ_DESC_F_NEXT |VIRTQ_DESC_F_WRITE);  //JUST RX BUFFER!

        // 2.  Link the rest of descriptors for the S/G buffers --
        n = in+out;
		for(i=1; i<n; i++) {
 			last_idx = vq->vring.desc[ pre_idx].next; //SHOULD BE NO CHANGE!
			if(last_idx >= vring->num){
				DPrintf(0, "[%s]ERROR: RX vqueue(%d/%p), got wrong descriptior link(%d, next:%d) from opaque(%p)!\n", __FUNCTION__,
					vq->index,vq, pre_idx, last_idx, opaque);

				vring->desc[pre_idx].flags &= (~VIRTQ_DESC_F_NEXT);
				vring->desc[pre_idx].next = pre_idx+1;
				return -EINVALIDRES;
			}

#if defined(VBOX_FixedBufferMaps_DBGLOG)
			if(vring->desc[ last_idx].addr != sg[i].physAddr.QuadPart){
				DPrintf(0, "[%s]ERROR: RX vqueue(%d/%p) vring item[idx:%d, current PA:0X%016I64X] is changing[new PA:0X%016I64X].\n", __FUNCTION__,
					vq->index,vq, last_idx, vring->desc[ last_idx].addr, sg[i].physAddr.QuadPart);
			}
			if(vring->desc[ last_idx].len != sg[i].length){
				DPrintf(0, "[%s]ERROR: RX vqueue(%d/%p) vring item[idx:%d, current length:%u] is changing[new length:%lu].\n", __FUNCTION__,
					vq->index,vq, last_idx, vring->desc[ last_idx].len, sg[i].length);
			}
#endif
			vring->desc[last_idx].addr = sg[i].physAddr.QuadPart;
			vring->desc[last_idx].len = sg[i].length;
			vring->desc[last_idx].flags = (VIRTQ_DESC_F_NEXT |VIRTQ_DESC_F_WRITE);

 			vring->desc[ pre_idx].next = last_idx;
			pre_idx = last_idx;
		}
		vring->desc[last_idx].flags &= (~VIRTQ_DESC_F_NEXT);
		vring->desc[last_idx].next = last_idx+1;

#if defined(VBOX_FixedBufferMaps_DBGLOG_XPNEED)
		if(n != 2){ //SHOULD BE SAME WITH the first adding!
			DPrintf(0, "[%s] WARNNING: vqueue(%d/%p),vring reusing item(%d)[descriptor idx:%d, addr:0X%016I64X(length:%d,in:%d,out:%d), opaque:%p] is strange(!=2).\n",
				__FUNCTION__,
				vq->index, vq, vq->master_vring_avail.idx,
				idx, vq->vring.desc[idx].addr, vq->vring.desc[idx].len, in, out,
				opaque);
		}
		if(vring->avail->idx != vq->master_vring_avail.idx){
			DPrintf(0, "[%s] ERROR: vqueue(%d/%p),vring lost the counter(avail idx:%d/local:%d).\n",
				__FUNCTION__,
				vq->index, vq, vring->avail->idx, vq->master_vring_avail.idx);
		}
#endif

    }

    // 3. Write the first descriptor into the available ring
    vring->avail->ring[DESC_INDEX(vring->num, vq->master_vring_avail.idx)] = idx;
    KeMemoryBarrier();

//Arley@20180809, VRINGDBG: some debug fields --
#if defined(VBOX_VRingDbgField)
	FirstUpdateVringAvailIdxShadow(vq);
#endif	
    vring->avail->idx = ++vq->master_vring_avail.idx;
    vq->num_added_since_kick++;

//Arley@20180416, IPERF3: if print, go dying!
#if defined(VBOX_FixedBufferMaps_DBGLOG)
	DPrintf(5, "[%s]vqueue(%d/%p),vring avail(%d)[idx:%d, addr:0X%016I64X(len:%d,in:%d,out:%d), opaque:%p].\n",
		__FUNCTION__,
		vq->index, vq, vq->master_vring_avail.idx,
		idx, vq->vring.desc[idx].addr, vq->vring.desc[idx].len, in, out,
		opaque);
#endif

//Arley@20180809, VRINGDBG: some debug fields --
#if defined(VBOX_VRingDbgField)
	if(vq->master_vring_avail.idx == 0){
		vring_avail_wrap_rounds(vring)++;
		DPrintf(0, "[%s]vqueue(%d/%p), vring.avai next[%X^%04X/%08X]/processing[%X^%04X],vring.used next[%X^%04X/%08X]/processing[%X^%04X].\n",
			__FUNCTION__,
			vq->index, vq,
			vring_avail_wrap_rounds( vring),vq->vring.avail->idx,vring_avail_idx_shadow(vring), 
			vring_processed_avail_rounds( vring),vring_processing_avail_idx( vring),
			vring_used_wrap_rounds( vring),vq->vring.used->idx, vring_used_idx_shadow( vring),
			vring_processed_used_rounds( vring),vring_processing_used_idx( vring));
	}
#endif

    return 0;
}


//Arley@20180809, VRINGDBG: some debug fields --
#if defined(VBOX_VRingDbgField)
#define ABS(v) (((v)<0)? -(v):(v))
static FORCEINLINE long TryingGetCorrectVringUsedIdx(struct virtqueue *vq)
{
	struct vring *vring = &vq->vring;
	u32 vring_used_idx_shadow32 = vring_used_idx_shadow( vring);
	u16 vring_used_idx16 = vring->used->idx;
	long corrected_idx = vring_used_idx16;

#if defined(VBOX_SUPPORT_NEWDRV)
	//Any shared variable is changing, try getting the valid value --
	for(int i=0; i<3; i++) {
		if (vring_idx_shadow_IsValid32(vring_used_idx_shadow32)){
			u16 shadow16 = vring_idx_shadow_GetValue16( vring_used_idx_shadow32);
			corrected_idx = shadow16;
			/*//Arley@20180821, Here don't want to waste time verifying the data, remark it!!!
			if(ABS(shadow16 - vring_used_idx16) > 0xFF) {
				DPrintf(0, "[%s]WARNNING/fixed(%d): vqueue(%d/%p), vring.avai next[%X^%04X/%08X]/processing[%X^%04X],vring.used next[%X^%04X/%08X->%08X]/processing[%X^%04X].\n",
					__FUNCTION__,i,
					vq->index, vq,
					vring_avail_wrap_rounds( vring),vq->vring.avail->idx, vring_avail_idx_shadow(vring),
					vring_processed_avail_rounds( vring),vring_processing_avail_idx( vring),
					vring_used_wrap_rounds( vring),vring_used_idx16, vring_used_idx_shadow32, corrected_idx,
					vring_processed_used_rounds( vring),vring_processing_used_idx( vring));
			}
			if((corrected_idx > vq->master_vring_avail.idx) &&
				(vring_used_wrap_rounds( vring) >=vring_avail_wrap_rounds(vring)))
			{
				corrected_idx = -1;
				DPrintf(0, "[%s]ERROR/illegal: vqueue(%d/%p), vring.avai next[%X^%04X/%08X]/processing[%X^%04X],vring.used next[%X^%04X/%08X->%08X]/processing[%X^%04X].\n",
					__FUNCTION__,
					vq->index, vq,
					vring_avail_wrap_rounds( vring),vq->vring.avail->idx, vring_avail_idx_shadow(vring),
					vring_processed_avail_rounds( vring),vring_processing_avail_idx( vring),
					vring_used_wrap_rounds( vring),vq->vring.used->idx, vring_used_idx_shadow( vring),corrected_idx,
					vring_processed_used_rounds( vring),vring_processing_used_idx( vring));
			}
			//*/
			return corrected_idx;
		}

		//Trying again for the verified shadow index --
		vring_used_idx_shadow32 = vring_used_idx_shadow( vring);
	}
#endif

	//If invalid shadow index, trying the original index value --
	if( vring_idx_maybe_Invalid16( vring_used_idx16 )) {
		vring_used_idx16 = vring->used->idx;
		corrected_idx = vring_used_idx16;
		if( vring_idx_maybe_Invalid16( vring_used_idx16 )) {
			//Shadow was invalid 3 times, and original maybe invalid 2 times, then warnning --
			DPrintf(0, "[%s]WARNNING/tried: vqueue(%d/%p), vring.avai next[%X^%04X/%08X]/processing[%X^%04X],vring.used next[%X^%04X/%08X->%08X]/processing[%X^%04X].\n",
				__FUNCTION__,
				vq->index, vq,
				vring_avail_wrap_rounds( vring),vq->vring.avail->idx, vring_avail_idx_shadow(vring),
				vring_processed_avail_rounds( vring),vring_processing_avail_idx( vring),
				vring_used_wrap_rounds( vring),vq->vring.used->idx, vring_used_idx_shadow( vring),corrected_idx,
				vring_processed_used_rounds( vring),vring_processing_used_idx( vring));
		}
	}
	return corrected_idx;
}
#endif

/* Gets the opaque pointer associated with a returned buffer, or NULL if no buffer is available */
void *virtqueue_get_buf(
    struct virtqueue *vq, /* the queue */
    unsigned int *len)    /* number of bytes returned by the device */
{
    void *opaque;
    u16 idx;
	long vring_used_idx =vq->vring.used->idx;

#if defined(VBOX_VRingDbgField)
 	vring_used_idx = TryingGetCorrectVringUsedIdx(vq);
	if(-1 == vring_used_idx) return NULL;
#endif

    if (vq->last_used == vring_used_idx) {
        /* No descriptor index in the used ring */
#if defined(VBOX_FixedBufferMaps_NoUseIndirect)
		DPrintf(1, "[%s]vqueue(%d/%p), no descriptor index in the vring.used[avail_idx(%d)/last_used(%d)].\n",
			__FUNCTION__,
			vq->index,vq,
			vq->master_vring_avail.idx,
			vq->last_used);

		/*//Arley@20180518, Bugproof: --
		[RX]If no data & so many idle buffers, kick it! (Or maybe all buffers used by VM driver, so no idles.)
		[TX/CX] If data pending no transmitted, kick it!
		//*/
		/*//Arley@20190107, Unstable TXK debugging --
		if((int)(vq->master_vring_avail.idx - vq->last_used) > (int)(vq->vring.num -8))
			virtqueue_kick_always( vq);
		//*/
#endif
        return NULL;
    }
    KeMemoryBarrier();

    idx = DESC_INDEX(vq->vring.num, vq->last_used);
    *len = vq->vring.used->ring[idx].len;

    /* Get the first used descriptor */
    idx = (u16)vq->vring.used->ring[idx].id;
    idx = DESC_INDEX(vq->vring.num, idx); //Arley@20180817, Bugproof: If abnormal memroy by VIRTIO.
    opaque = vq->opaque[idx];

#if defined(VBOX_FixedBufferMaps_NoUseIndirect)
//If not reusing , then put back the chain.
if(vq->fBufferReusing == 0)
#endif
{
    /* Put all descriptors back to the free list */
    put_unused_desc_chain(vq, idx);
}

    vq->last_used++;
    if (vq->vdev->event_suppression_enabled && virtqueue_is_interrupt_enabled(vq)) {
        vring_used_event(&vq->vring) = vq->last_used;
        KeMemoryBarrier();
    }

//Arley@20180416, IPERF3: if print, go dying!
#if defined(VBOX_FixedBufferMaps_DBGLOG)
	DPrintf(5, "[%s]vqueue(%d/%p), vring used[idx/%d, addr/0X%016I64X, opaque:%p].\n",
		__FUNCTION__,
		vq->index, vq,
		idx, vq->vring.desc[idx].addr, opaque);
#endif

//Arley@20180809, VRINGDBG: some debug fields --
#if defined(VBOX_VRingDbgField)
    {struct vring *vring = &vq->vring;
	vring_processing_used_idx( vring) = vq->last_used -1;
	if(vq->last_used == 0){
		DPrintf(0, "[%s]vqueue(%d/%p), vring.avai next[%X^%04X/%08X]/processing[%X^%04X],vring.used next[%X^%04X/%08X]/processing[%X^%04X].\n",
			__FUNCTION__,
			vq->index, vq,
			vring_avail_wrap_rounds( vring),vq->vring.avail->idx,vring_avail_idx_shadow(vring), 
			vring_processed_avail_rounds( vring),vring_processing_avail_idx( vring),
			vring_used_wrap_rounds( vring),vq->vring.used->idx, vring_used_idx_shadow( vring),
			vring_processed_used_rounds( vring),vring_processing_used_idx( vring));

		vring_processed_used_rounds( vring)++;
	}}
#endif

    ASSERT(opaque != NULL);
    return opaque;
}

/* Returns true if at least one returned buffer is available, false otherwise */
BOOLEAN virtqueue_has_buf(struct virtqueue *vq)
{
	long vring_used_idx =vq->vring.used->idx;

#if defined(VBOX_VRingDbgField)
 	vring_used_idx = TryingGetCorrectVringUsedIdx(vq);
	if(-1 == vring_used_idx) return FALSE;
#endif

    return (vq->last_used != vring_used_idx);
}

/* Returns true if the device should be notified, false otherwise */
bool virtqueue_kick_prepare(struct virtqueue *vq)
{
    bool wrap_around;
    u16 old, new;
    KeMemoryBarrier();

    wrap_around = (vq->num_added_since_kick >= (1 << 16));

    old = (u16)(vq->master_vring_avail.idx - vq->num_added_since_kick);
    new = vq->master_vring_avail.idx;
    vq->num_added_since_kick = 0;

    if (vq->vdev->event_suppression_enabled) {
        return wrap_around || (bool)vring_need_event(vring_avail_event(&vq->vring), new, old);
    } else {
        return !(vq->vring.used->flags & VIRTQ_USED_F_NO_NOTIFY);
    }
}

/* Notifies the device even if it's not necessary according to the event suppression logic */
void virtqueue_kick_always(struct virtqueue *vq)
{
	/*//ms-help://MS.WDK.v10.7600.091201/Kernel_r/hh/Kernel_r/k105_972df62d-6449-40d7-9bfa-0c420cf8f106.xml.htm
	KeMemoryBarrier --
 	FORCEINLINE VOID KeMemoryBarrier (VOID)	{
	    LONG Barrier;
	    __asm {
	        xchg Barrier, eax
	    }
	}
	In this definition, the braces that follow the __asm keyword contain inline assembly code. 
	The compiler optimizer cannot move an instruction from a position 
	  before the inline assembly code to a position after the inline assembly code, 
	  and vice versa. 
	In addition, the xchg instruction implicitly includes the lock prefix, 
	  which forces the processor hardware to complete the memory operations for all instructions that precede the xchg instruction 
	  before it initiates memory operations for instructions that follow the xchg instruction.
	//*/
    KeMemoryBarrier();
    vq->num_added_since_kick = 0;
    virtqueue_notify(vq);
}

/* Enables interrupts on a virtqueue and returns false if the queue has at least one returned
 * buffer available to be fetched by virtqueue_get_buf, true otherwise */
bool virtqueue_enable_cb(struct virtqueue *vq)
{
    if (!virtqueue_is_interrupt_enabled(vq)) {
        vq->master_vring_avail.flags &= ~VIRTQ_AVAIL_F_NO_INTERRUPT;
        if (!vq->vdev->event_suppression_enabled)
        {
            vq->vring.avail->flags = vq->master_vring_avail.flags;
        }
    }

    vring_used_event(&vq->vring) = vq->last_used;
    KeMemoryBarrier();
    return (vq->last_used == vq->vring.used->idx);
}

/* Enables interrupts on a virtqueue after ~3/4 of the currently pushed buffers have been
 * returned, returns false if this condition currently holds, false otherwise */
bool virtqueue_enable_cb_delayed(struct virtqueue *vq)
{
    u16 bufs;

    if (!virtqueue_is_interrupt_enabled(vq)) {
        vq->master_vring_avail.flags &= ~VIRTQ_AVAIL_F_NO_INTERRUPT;
        if (!vq->vdev->event_suppression_enabled)
        {
            vq->vring.avail->flags = vq->master_vring_avail.flags;
        }
    }

    /* Note that 3/4 is an arbitrary threshold */
    bufs = (u16)(vq->master_vring_avail.idx - vq->last_used) * 3 / 4;
    vring_used_event(&vq->vring) = vq->last_used + bufs;
    KeMemoryBarrier();
    return ((vq->vring.used->idx - vq->last_used) <= bufs);
}

/* Disables interrupts on a virtqueue */
void virtqueue_disable_cb(struct virtqueue *vq)
{
    if (virtqueue_is_interrupt_enabled(vq)) {
        vq->master_vring_avail.flags |= VIRTQ_AVAIL_F_NO_INTERRUPT;
        if (!vq->vdev->event_suppression_enabled)
        {
            vq->vring.avail->flags = vq->master_vring_avail.flags;
        }
    }
}

/* Returns true if interrupts are enabled on a virtqueue, false otherwise */
BOOLEAN virtqueue_is_interrupt_enabled(struct virtqueue *vq)
{
    return !(vq->master_vring_avail.flags & VIRTQ_AVAIL_F_NO_INTERRUPT);
}

/* Initializes a new virtqueue using already allocated memory */
struct virtqueue *vring_new_virtqueue(
    unsigned int index,                 /* virtqueue index */
    unsigned int num,                   /* virtqueue size (always a power of 2) */
    unsigned int vring_align,           /* vring alignment requirement */
    VirtIODevice *vdev,                 /* the virtio device owning the queue */
    void *pages,                        /* vring memory */
    void (*notify)(struct virtqueue *), /* notification callback */
    void *control)                      /* virtqueue memory */
{
    struct virtqueue *vq = (struct virtqueue *)control;
    u16 i;

    if (DESC_INDEX(num, num) != 0) {
        DPrintf(0, "Virtqueue length %u is not a power of 2\n", num);
        return NULL;
    }

    RtlZeroMemory(vq, sizeof(*vq) + num * sizeof(void *));

    vring_init(&vq->vring, num, pages, vring_align);
    vq->vdev = vdev;
    vq->notification_cb = notify;
    vq->index = index;
		
    /* Build a linked list of unused descriptors */
    vq->num_unused = num;
    vq->first_unused = 0;
    for (i = 0; i < num - 1; i++) {
        vq->vring.desc[i].flags = VIRTQ_DESC_F_NEXT;
        vq->vring.desc[i].next = i + 1;
    }

//Arley@20180416, IPERF3: VBOX kernel needs fixed buffer maps(idx, addr)!
#if defined(VBOX_FixedBufferMaps_NoUseIndirect)
	//If add when reusing , then crash.
	vq->fBufferReusing = 0;
#endif

//Arley@20180809, VRINGDBG: some debug fields --
#if defined(VBOX_VRingDbgField)
	//VRing section pointers --
	{struct vring *vr = &vq->vring;
	DPrintf(0, "[%s]vqueue(%d/%p): vring(%p, count:%d), desc[%p]/avail[%p]/used[%p].\n",
		__FUNCTION__,
		vq->index, vq,
		vr, vr->num, vr->desc, vr->avail, vr->used);
	}
#endif

    return vq;
}

/* Re-initializes an already initialized virtqueue */
void virtqueue_shutdown(struct virtqueue *vq)
{
    unsigned int num = vq->vring.num;
    void *pages = vq->vring.desc;
    unsigned int vring_align = vq->vdev->addr ? PAGE_SIZE : SMP_CACHE_BYTES;

    RtlZeroMemory(pages, vring_size(num, vring_align));
    (void)vring_new_virtqueue(
        vq->index,
        vq->vring.num,
        vring_align,
        vq->vdev,
        pages,
        vq->notification_cb,
        vq);
}

/* Gets the opaque pointer associated with a not-yet-returned buffer, or NULL if no buffer is available
 * to aid drivers with cleaning up all data on virtqueue shutdown */
void *virtqueue_detach_unused_buf(struct virtqueue *vq)
{
    u16 idx;
    void *opaque = NULL;

    for (idx = 0; idx < (u16)vq->vring.num; idx++) {
        opaque = vq->opaque[idx];
        if (opaque) {
            put_unused_desc_chain(vq, idx);
            vq->vring.avail->idx = --vq->master_vring_avail.idx;
            break;
        }
    }
    return opaque;
}

/* Returns the base size of the virtqueue structure (add sizeof(void *) times the number
 * of elements to get the the full size) */
unsigned int vring_control_block_size()
{
    return sizeof(struct virtqueue);
}

/* Negotiates virtio transport features */
void vring_transport_features(
    VirtIODevice *vdev,
    u64 *features) /* points to device features on entry and driver accepted features on return */
{
    unsigned int i;

    for (i = VIRTIO_TRANSPORT_F_START; i < VIRTIO_TRANSPORT_F_END; i++) {
        if (i != VIRTIO_RING_F_INDIRECT_DESC &&
            i != VIRTIO_RING_F_EVENT_IDX &&
            i != VIRTIO_F_VERSION_1) {
            virtio_feature_disable(*features, i);
        }
    }
}

/* Returns the max number of scatter-gather elements that fit in an indirect pages */
u32 virtio_get_indirect_page_capacity()
{
    return PAGE_SIZE / sizeof(struct vring_desc);
}
