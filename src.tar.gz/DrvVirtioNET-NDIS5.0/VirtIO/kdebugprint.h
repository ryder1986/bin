#pragma once

/*//Arley@20180307,DBG: Global switch, just a declaration, Here implemented in ParaNdis-Debug.cpp.
About DebugLevel:
0- Once when running, such as configuration routine/initializing funtions.
0/1/2- Any fatal error.
2/3/4- Other exceptions when running, messages when debugging.
5/6/7- Loop messages when debugging.
7- Messages making low performance when printing.
//*/
extern int g_nVirtioDebugLevel;
extern int g_bDebugPrint;

typedef void (*tDebugPrintFunc)(const char *format, ...);
extern tDebugPrintFunc VirtioDebugPrintProc;

#define DPrintf(Level, MSG, ...) if(g_bDebugPrint && (Level)<= g_nVirtioDebugLevel) VirtioDebugPrintProc(MSG, __VA_ARGS__)

#define DEBUG_ENTRY(level)  DPrintf(level, "[%s]=>\n", __FUNCTION__)
#define DEBUG_EXIT_STATUS(level, status) DPrintf((status == NDIS_STATUS_SUCCESS ? level : 0), "[%s]<=0x%X\n", __FUNCTION__, (status))

//Arley@20180411, IPERF3: Nothing, even no 'if' cost.
#if defined(DRV_RELEASE)
#undef DPrintf
#undef DEBUG_ENTRY
#undef DEBUG_EXIT_STATUS
#define DPrintf(Level, MSG, ...)
#define DEBUG_ENTRY(level)
#define DEBUG_EXIT_STATUS(level, status)
#endif

