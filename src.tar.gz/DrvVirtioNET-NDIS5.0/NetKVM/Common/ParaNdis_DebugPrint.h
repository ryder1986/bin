/*
 * This file contains debug-related definitions for kernel driver
 *
 * Copyright (c) 2008-2017 Red Hat, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met :
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and / or other materials provided with the distribution.
 * 3. Neither the names of the copyright holders nor the names of their contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
 /**********************************************************************
WARNING: this file is incompatible with Logo requirements
TODO:    Optional WPP technique
**********************************************************************/
#ifndef _PARANDIS_DEBUG_PRINT_H
#define _PARANDIS_DEBUG_PRINT_H
#include "DebugData.h"

/*//Arley@20180307,DBG: Global switch, just a declaration, Here implemented in ParaNdis-Debug.cpp.
About DebugLevel:
0- Once when running, such as configuration routine/initializing funtions.
1/2- Any fatal error.
3/4- Other exceptions when running, messages when debugging.
5/6- Loop messages when debugging.
7- Messages making low performance when printing.
//*/
extern int g_nVirtioDebugLevel;
extern int g_bDebugPrint;

typedef void (*DEBUGPRINTFUNC)(const char *fmt, ...);
extern  DEBUGPRINTFUNC g_pfnDebugPrint;

//Arley@20180307,b: must be the string macro --
#define DoPrintX(fmt,...)  g_pfnDebugPrint(fmt##"\n",__VA_ARGS__)
#define DPrintf(a,b) {if (g_bDebugPrint && (a)<= g_nVirtioDebugLevel) DoPrintX b;}
#define DEBUG_ENTRY(level)  DPrintf(level, ("[%s]=>...", __FUNCTION__))
#define DEBUG_EXIT_STATUS(level, status) DPrintf(level, ("[%s]<=status(0x%X)", __FUNCTION__, (status)))

void _LogOutEntry(int level, const char *s);
void _LogOutExitValue(int level, const char *s, ULONG value);
void _LogOutString(int level, const char *s);


/*//Arley@20180403, MARK: WPP Software Tracing -û���������ã�
This section describes how to use the default operation of the Windows software trace preprocessor(WPP) to trace a driver's operation.
WPP software tracing is supported on Microsoft Windows 2000 and later.

WPP software tracing in kernel - mode drivers supplements and enhances WMI event tracing by adding conventions and mechanisms that simplify tracing a driver's operation.
It is an efficient mechanism for user-mode applications and kernel-mode drivers to log real-time binary messages.
The logged messages can subsequently be converted to a human-readable trace of the driver's operation.

Logging messages with WPP software tracing is similar to using Windows event logging services.
The driver logs a message ID and unformatted binary data in a log file.Subsequently, a postprocessor converts the information in the log file to a human - readable form.
However, WPP software tracing supports message formats that are more capable and flexible than that supported by the event logging services.
//*/
#define WPP_INIT_TRACING(a,b)
#define WPP_CLEANUP(a)
#define WPP_MAX_DBGLEVEL 1
#define WPP_USE_BYPASS 0
#define DPrintfBypass(Level, Fmt, ...) DPrintf(Level, Fmt, __VA_ARGS__)

#ifdef WPP_EVENT_TRACING
#define DPrintfAnyway(Level, Fmt) { \
    if (g_bDebugPrint && (Level) <= g_nVirtioDebugLevel){ \
        g_pfnDebugPrint Fmt; \
    }}

#if WPP_USE_BYPASS
#define DPrintfBypass(Level, Fmt) DPrintfAnyway(Level, Fmt)
#else
#define DPrintfBypass(Level, Fmt)
#endif

//{05F77115-E57E-49bf-90DF-C0E6B6478E5F}
#define WPP_CONTROL_GUIDS \
    WPP_DEFINE_CONTROL_GUID(NetKVM, (05F77115,E57E,49bf,90DF,C0E6B6478E5F),  \
        WPP_DEFINE_BIT(TRACE_DEBUG))

#define WPP_LEVEL_ENABLED(LEVEL) \
    (g_nVirtioDebugLevel >= (LEVEL))

#define WPP_LEVEL_LOGGER(LEVEL)      (WPP_CONTROL(WPP_BIT_ ## TRACE_DEBUG).Logger),

#define WPP_PRIVATE_ENABLE_CALLBACK     WppEnableCallback
extern VOID WppEnableCallback(
    __in LPCGUID Guid,
    __in __int64 Logger,
    __in BOOLEAN Enable,
    __in ULONG Flags,
    __in UCHAR Level);

#endif
#endif
